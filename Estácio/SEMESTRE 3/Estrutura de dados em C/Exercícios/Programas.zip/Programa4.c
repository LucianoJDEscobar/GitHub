//Programa 4
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
  int i;
  scanf("%i", &i);
  printf("%i\n", i);
  return (0);
}

