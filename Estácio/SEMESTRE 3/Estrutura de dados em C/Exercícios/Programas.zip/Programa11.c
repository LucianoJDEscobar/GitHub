//Programa imprime o valor da vari�vel num
#include <stdio.h> 
int num;
num = 20;
int main ()
{
  int num;  
  num = 10;
  printf("O valor da variavel num: %d", num); 
  return 0;
}
