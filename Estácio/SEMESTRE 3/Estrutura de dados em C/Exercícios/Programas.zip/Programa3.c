//Programa 3
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
  int i; double pi;
  i=123; pi=3.14;
  printf("%d %f\n", i, pi);
  system("PAUSE");
  return(0);
}

