//Programa 2
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
  double pi;
  pi=3.14;
  printf("%f\n", pi);
  return(0);
}

